import sys
import socket
import struct
from datetime import datetime

endi = "<"
pcap_file = 0
read_pcap_file = 0
decoded = 0
counter = 0
pcap_index_1 = 24
# Between 24 to 40, is the first packet header.
pcap_index_2 = pcap_index_1 + 16

pcap_file = open("CyberSecurity.pcap", "rb")
read_pcap_file = pcap_file.read()

decoded = read_pcap_file.decode("iso-8859-1")

domain_name = [".top"]

websites_found = []

for i in domain_name:
    if i in decoded:
        websites_found.append(i)

print(websites_found)

pcap_headers = struct.unpack(endi + "IHHIIII", read_pcap_file[:24])
snaplength = pcap_headers[5]


while True:
    if counter > 2:
        break
    else:

        pcap_packet_header = struct.unpack(endi+"IIII", read_pcap_file[pcap_index_1:pcap_index_2])
        cap_len = pcap_packet_header[3]
        print(pcap_index_1, pcap_index_2)

        print("cap len:", cap_len)
        print(pcap_packet_header)
        timestamp = pcap_packet_header[0]
        timestamp = datetime.fromtimestamp(timestamp)
        print("Counter: " , counter, "Timestamp in s:", timestamp)
        input()

        #pcap header requires 16 bytes from the first index
        #first index = last index 
        #second index is the first index plus 16
        #read header then add 34 bytes to skip other headers
        #first index is second index plus 16
        #second index is cap_len

        pcap_index_1 = pcap_index_1 + 34
        pcap_index_2 = cap_len

        x = read_pcap_file[pcap_index_1:pcap_index_2]

        if ".top".encode() in x:
            print(counter)
            print(pcap_index_1, pcap_index_2)
            print(".top found in file...")
            break
        else:
            pass
        
        pcap_index_1 = cap_len
        pcap_index_2 = cap_len + 16

        print(pcap_index_1, pcap_index_2)

        counter+=1
        input()
