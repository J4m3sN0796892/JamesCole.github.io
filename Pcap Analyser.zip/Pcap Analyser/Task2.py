import struct
from datetime import datetime
import socket

def packetAnalyser():
    file=open("CyberSecurity.pcap", "rb")
    read_file = file.read()
    endi = "<"
    
    def formatMAC(mac):
        x=[]
        frst=0
        lst=2
        macformat = ""
        for i in mac:
            x.append(mac[frst:lst]+":")
            frst=lst
            lst = lst+2
        macformat = macformat.join(x)
        macformat = macformat[0:17]+macformat[24 + 1::]
        return macformat

    pcap_index_1 = 24
    pcap_index_2 = 24 + 16
    frameLen = 0

    #Packet header(16 bytes)
    pcap_packet_header = struct.unpack(endi + "IIII", read_file[pcap_index_1:pcap_index_2])
    timestamp = pcap_packet_header[0]
    timestamp = datetime.fromtimestamp(timestamp)

    print("Packet timestamp:", pcap_packet_header[0])
    print("Packet timestamp (GMT):", timestamp)
    print("Frame Length:", pcap_packet_header[3])
    
    frameLenSet = int(pcap_packet_header[3])+24
    frameLen = int(pcap_packet_header[3]) - 16

    
    #Ethernet header(14 bytes)
    pcap_index_1 = pcap_index_2
    pcap_index_2 = pcap_index_2 + 14
    pcap_packet_header = struct.unpack(endi + "6s6sH", read_file[pcap_index_1:pcap_index_2])
    dst = pcap_packet_header[0].hex()
    src = pcap_packet_header[1].hex()
    
    print("Destination MAC address: "+formatMAC(dst))
    print("Source MAC address: "+formatMAC(src))
    print("Link type: "+str(pcap_packet_header[2]))
    frameLen = frameLen - 14

    #IPv4 header 20Bytes
    pcap_index_1 = pcap_index_2
    pcap_index_2 = pcap_index_2 + 20
    pcap_packet_header = struct.unpack(endi + "12x 4s4s", read_file[pcap_index_1:pcap_index_2])
    addr=int(pcap_packet_header[0].hex(), 16)
    print("Source IPv4: "+socket.inet_ntoa(struct.pack(">L", addr)))
    addr=int(pcap_packet_header[1].hex(), 16)
    print("Destination IPv4: "+socket.inet_ntoa(struct.pack(">L", addr)))

    frameLen = frameLen - 20
    
    #UDP header(8 bytes)
    frameLen = frameLen - 8
    
    pcap_index_1 = pcap_index_2
    pcap_index_2 = frameLenSet + 16

    print(pcap_index_1)
    print(pcap_index_2)

    print(read_file[pcap_index_1:pcap_index_2])

packetAnalyser()
