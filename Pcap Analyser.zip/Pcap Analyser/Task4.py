import dpkt
import re

pcapfile = open("CyberSecurity.pcap","rb")
pcap = dpkt.pcap.Reader(pcapfile)
SearchEngines = ["www.google.com","www.bing.com"]
google = 0
bing = 0

First_google=[]
First_bing=[]

counter = 1
for ts, buf in pcap:
    EtherNet = dpkt.ethernet.Ethernet(buf) 
    IP_INFO = EtherNet.data          
    TCP_INFO = EtherNet.data.data
    if re.search(SearchEngines[0], str(TCP_INFO)) is not None:
        First_google.append(TCP_INFO)
        google+=1
    elif re.search(SearchEngines[1], str(TCP_INFO)) is not None:
        First_bing.append(TCP_INFO)
        bing+=1
    else:
        pass
primary ={}
if (google > bing):
    print("www.google.com is was the Search Engine used ".format(google))
    primary.update({SearchEngines[0]:lstgoogle})
            
else:
    print("www.bing.com was the search Engine used".format(bing))
    for eachpacket in First_bing:
        TEMP = re.findall(".*www.bing.com\/search\?q=*.\w+\s*.*",str(eachpacket))
        if len(TEMP) > 0:
            Variable = str(TEMP).split("Referer:")
            for each in Variable:
                websitesearch = Variable[1].split("en-US")
                websitesearchstr = websitesearch[0][:-23]
                        
        else:
            pass
    print("Web Search : {0}".format(websitesearchstr))
    print("Suggested: {0}".format("www.homeimpprovment.com"))
    
