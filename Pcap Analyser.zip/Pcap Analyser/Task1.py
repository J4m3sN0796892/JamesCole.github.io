import struct

#needs to be angle brackets because thats how the struct module does things
little_Endian = "<"
big_Endian = ">"
endianness = ""

#time to open the file
with open("CyberSecurity.pcap", "rb") as the_File:
    read_File = the_File.read()
if read_File[:2] == b"\xa1\xb2":
    endianness = big_Endian
    print("Endian = Big Endian")
    
elif read_File[:2] == b"\xd4\xc3":
    endianness = little_Endian
    print("Endian = Little Endian")

#unpacks and adds to a list type thinggy
pcap_headers = struct.unpack(endianness + "IHHIIII", read_File[:24])


# this is getting all the info
print("Major version =", pcap_headers[1])
print("Minor version =", pcap_headers[2])
print("Time Zone =",pcap_headers[3])
print("Accuracy of timestamps =", pcap_headers[4])
print("Snap Len =",pcap_headers[5])
print("Network Type =",pcap_headers[6])


print("full Global Header =",pcap_headers)
