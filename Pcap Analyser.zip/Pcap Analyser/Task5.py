import socket
import os

s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)

counter=[]

def main(target):
	print("Testing connection")
	for x in range(0, 1000):
		n = s.connect_ex((target, x))
		if n == 0:
			print("[+] PORT:", x, "OPEN")
			counter.append(x)
		else:
			print("[-] PORT:", x, "closed")
	print(counter)

target = input("Enter target IP: ")
main(target)
