from collections import defaultdict
#Default dict works like a normal dictionary but has standard values if there are no others.

from heapq import *
#priority queue
class Login_Manage():
    
    def Login():
        _User = input("To Continue, Please Enter username\n")
        _Password = input("Please enter password\n")
        if _User =="Admin" and _Password =="Admin":
                Login_Manage.AddUser()
            
        Logins = open("Logins.txt","r")
        for line in Logins.readlines():
            TempLog = line.split()
            if _User == TempLog[0] and _Password == TempLog[1]:
                print("correct Credentials")
                break
            else:
                print("Incorrect Login Credentials. Please Try Again\n")
                Login_Manage.Login()
            
    def AddUser():
        NewUser = input("Please enter the new username\n")
        NewPass = input("Please enter the new password for the user\n")
        User=open("Logins.txt","a")
        
        User.write(NewUser)
        User.write(" ")
        User.write(NewPass)
        User.write("\n")
        User.close
        
def Menu():

    Vertexs = ["London","Bath","Edinburgh","Glasgow","Grantham","Nottingham","Birmingham"]
    
    Connected_Verticies = [
            ("London", "Bath", 22.65),
            ("London", "Grantham", 28.40),
            ("London", "Nottingham", 40.65),
            ("Bath", "London", 22.65),
            ("Bath", "Birmingham", 39.15),
            ("Birmingham", "Nottingham", 8.50),
            ("Birmingham", "Bath", 39.15),
            ("Nottingham", "Birmingham", 8.50),
            ("Nottingham","London",40.65),
            ("Nottingham","Grantham",6.10),
            ("Grantham","Nottingham",6.10),
            ("Grantham","London",28.40),
            ("Grantham","Edinburgh",81.80),
            ("Edinburgh","Grantham",81.80),
            ("Edinburgh","Glasgow",8.50),
            ("Glasgow","Edinburgh",8.50)
            ]
    Start = input("Where are you starting your journey? (London,Nottingham,Edinburgh,Bath,Birmingham,Glasgow or Grantham)\n")
    if Start not in Vertexs:
        print("Please Enter a Valid Station Pair\n\n\n\n")
        Menu()
        
    End = input("Where are you ending your journey? (London,Nottingham,Edinburgh,Bath,Birmingham,Glasgow or Grantham)\n")
    if End not in Vertexs:
        print("Please enter a valid station pair\n\n\n\n")
        Menu()
    
    print (Start," ->", End +":")

    print ( _Dijkstra(Connected_Verticies, Start, End),"\n\n\n")



def _Dijkstra(Connected_Verticies, _from, _to):
   
    graph = defaultdict(list)
    
    for left,right,connected in Connected_Verticies:
        
        graph[left].append((connected,right))

    THISONE= [(0,_from,())]
    
    seen= set()
    
    price =  {_from: 0}
    
    while THISONE:
        
        (cost,vertex1,path) = heappop(THISONE)
        
        if vertex1 not in seen:
            seen.add(vertex1)
            path = (vertex1, path)
            if vertex1 == _to: return (cost, path)

            for each, vertex2 in graph.get(vertex1, ()):
                
                if vertex2 in seen: continue
                prev = price.get(vertex2, None)
                next = cost + each
                if prev is None or next < prev:
                    price[vertex2] = next
                    heappush(THISONE, (next, vertex2, path))
                
   #return float("inf")



while 1:
    Login_Manage.Login()
    Response = input("Are you Planning a journey?\n")
    if Response =="Yes":
        Menu()
    else:
        break
    
        
