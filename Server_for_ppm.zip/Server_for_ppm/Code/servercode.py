import socket
import sys
import hashlib
import threading
import os
import re
import datetime
from subprocess import call
SEPARATOR = "<SEPARATOR>"
BUFFER_SIZE = 2048

class ClientThread(threading.Thread): 
 
    def __init__(self,ip,port): 
        threading.Thread.__init__(self) 
        self.ip = ip 
        self.port = port 
       
 
    def run(self): 
        
        print("YUP")
        

class ClientThread(threading.Thread): 
 
    def __init__(self,ip,port): 
        threading.Thread.__init__(self) 
        self.ip = ip 
        self.port = port 
        
 
    def run(self): 
        
        data = conn.recv(1024).decode()
        print ("Server received data:", data)   
        FileName = "Login.txt"
        file = open(FileName,"r")
        for line in file:
            print(data)
            print(line)
            if line  == data:
                conn.send("valid".encode())
            else:
                conn.send("invalid".encode())

       
        #Part where the camera listening code goes
        while 1:
            fileList = []
            for files in os.listdir(data):
               
                if files.endswith(".h264"):
                    fileList.append(files)

            fileList = str(fileList)
            conn.send(fileList.encode())
                
            secondList =[]
            vid = conn.recv(1024).decode()
            vid = int(vid)
            print(vid)
            fileList = []
            for item in os.listdir(data):

                if item.endswith(".h264"):
                    secondList.append(item)
                    print(secondList)
            print(secondList[vid])
            
            video = int(vid)
            vid = secondList[video]
            print(secondList[video])
            SendyWendy(vid,data)

def SendyWendy(vid,data):

        startpath =""
    

        filename = os.path.join(startpath,data, vid)

        
        filesize = os.path.getsize(filename)
        conn.send(f"{filename}{SEPARATOR}{filesize}".encode('latin-1'))
        print("WE HERE")
        #In the same folder or path is this file running must the file you want to tranfser to be
        f = open(filename,'rb')
        l = f.read(4096)
        while (l):
           conn.send(l)
          
           l = f.read(4096)
        
        f.close()
        print("Sent")

        
        
            
    
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost",4000))
server.listen(10) # Accepts up to 10 connections.

while True:
    (conn,(ip,port)) = server.accept()
    User = conn.recv(1024).decode()
    reply = conn.send("Loging in".encode())
    print(User)
    if User == "C":
        camera = CameraThread(ip,port)
        camera.start()
    else:
         newthread = ClientThread(ip,port) 
         newthread.start() 
    
    
    
   
#s.close()

#s.close()
