import picamera
import datetime
from time import sleep
from subprocess import call
from gpiozero import LED
from gpiozero import MotionSensor
import socket
import os
host = "192.168.0.13"
port = 8080
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)



def Establish_Connection():

    s.connect((host,port))


    print("connected")

    record()

def record():

    #sets up the camera
    with picamera.PiCamera() as camera:
        #starts the recording
       
       
        PIR = MotionSensor(4)
       

        while True:
           
            PIR.wait_for_motion()
       
            filename = "SecuriityCam.h264"
            camera.start_recording(filename)
            sleep(5) #duration
       
           
            PIR.wait_for_no_motion()
           
            camera.stop_recording()
            base  = os.path.splitext(filename)[0]
            print ("The attributes of now() are : ")
           
           
           
            print(filename)
           
            print("Video Saved")
           
           
            Send_File(filename)
def Send_File(filename):
   
   
   
    s.send(filename.encode('latin-1'))
   
   
    f = open(filename,'rb')
    l = f.read(4096)
   
    while (l):
        s.send(l)
        print(filename)
        l = f.read(4096)
   
    f.close()
    s.send(l)
    #os.remove(filename)
    print("Sent")
   
Establish_Connection()
