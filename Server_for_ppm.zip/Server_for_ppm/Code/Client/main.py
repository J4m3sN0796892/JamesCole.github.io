import tkinter as tk
import socket
import hashlib
import re
import os

SEPARATOR = "<SEPARATOR>"
BUFFER_SIZE = 4096
port = 4000
host = "127.0.0.1"
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
class LoginPage(tk.Frame):
    
    # This is for when you enter the username/password, it would then run the function from the text to the text boxes and put it into variables.
    def submit(self):
        username = self.username.get()
        password = self.password.get()
    
        
        s.connect((host, port))
        Connection_type = "A"
        s.send(Connection_type.encode())
        acknowledge = s.recv(1024).decode()
        print(acknowledge)

        SendPass = hashlib.sha256(password.encode()).hexdigest()
        SendUser = hashlib.sha256(username.encode()).hexdigest()  
        Credentials = SendUser + SendPass
        print(Credentials)
        s.send(Credentials.encode())
        print("Loging in")
        val = s.recv(1024).decode()
        print(val)
        if val == "valid":
            loginVAR = True
            # If this is true and it does match it would kill the current frame and start from the next part of the program.
            self.loginElement.destroy()
            self.verify.destroy()
            main_app = MainApp(root)
        else:
            self.verify.config(text="Incorrect username or password")
            print("False")
            return False
      
    def loginInput(self):
        # Creating the new frame
        self.loginElement = tk.Frame(self.master)
        loginElement = self.loginElement
        # This is creating the application which would have two fields. One for Username other for Password. By making the width etc.
        tk.Label(loginElement, text="Login").pack()
        tk.Label(loginElement, text="Username").pack()
        self.username = tk.Entry(loginElement)
        self.username.config(width=50)
        self.username.pack()
        tk.Label(loginElement, text="Password").pack()
        self.password = tk.Entry(loginElement, show="*")
        self.password.config(width=50)
        self.password.pack()
        # This is passing the functions with parmeters. (limit the process of the activity)
        self.submitButton = tk.Button(loginElement,text="Login", command=lambda: self.submit())
        # Placement of the button
        self.submitButton.pack(side=tk.BOTTOM)
        # Finalisation and implementation of the button
        self.verify = tk.Label(loginElement, text="")
        self.verify.pack(side=tk.BOTTOM)
        self.loginElement.pack()

    # Calls previous login input
    def __init__(self, master):
        self.master = master
        tk.Frame.__init__(self, self.master)
        self.loginInput()


# Calls everything which was defined previously
class MainApp(tk.Frame):
    
    def __init__(self, master):
        self.master = master
        tk.Frame.__init__(self, self.master)
        
      
        
        
        self.loadLog()
      
 
    # This is the log where the videos would be stored

    def Request_Vid(self,videoLog):
        value=str((videoLog.curselection()))
        print(value)
        vid = re.search(r'\((.*?)\)',value).group(1)
        vid = vid.replace(',', '')
        video = vid.rstrip()

        print(video)
        s.send(video.encode())
        video = ""
        
        

       

        
        received = s.recv(BUFFER_SIZE).decode('latin-1')
        filename, filesize = received.split(SEPARATOR)
        # remove absolute path if there is
        filename = os.path.basename(filename)
        s.settimeout(1)    
        filesize = int(filesize)
        i=0
        save_path = 'Videos'
        name_of_file = filename

        completeName = os.path.join(save_path, name_of_file)         

        
        with open(completeName, "wb") as f:                     
            while  i==0:
             # read 2048 bytes from the socket (receive)
               bytes_read = s.recv(4096)
               
               if not bytes_read:
                    i=1
                    break
               f.write(bytes_read)
             
            print("Completed")
            f.close()
        

    
    def loadLog(self):
        self.logFrame = tk.Frame(self.master, background="grey")
        self.videoLog = tk.Listbox(self.logFrame)
        videoLog = self.videoLog
        videoLog.config(width=100)
        logList= []
        #data =pickle.loads(s.recv(2014))
        data = s.recv(4096)
        # Decode received data into UTF-8
        data = data.decode('utf-8')
        # Convert decoded data into list
        
        data = eval(data)
        
        print(data)
        #print(logList)
        i=0
        while i < len(data):
            
            videoLog.insert(i, data[i])
            i+=1
         #os.startfile("C:\Documents and Settings\flow_model\flow.exe")

            
        videoLog.pack()
        self.logFrame.pack(side=tk.BOTTOM)
        self.play = tk.Button(self.logFrame,text="Download", command= lambda: self.Request_Vid(self.videoLog))
        self.play.pack(side=tk.BOTTOM)
        self.loadToolbar()
   
    # Making the Menu bar, implimenting different features.
    def loadToolbar(self):
      
       
        menubar = tk.Menu(self.master)
        
        root.config(bg='#2A2C2B', menu=menubar)
        VideoMenu = tk.Menu(menubar,tearoff=0, background='#000099',
foreground='white',
                activebackground='#004c99', activeforeground='white')
       
        VideoMenu.add_command(label="Update Log",command =lambda: self.update(menubar,VideoMenu))
        menubar.add_cascade(label="Watch Videos", menu=VideoMenu)

        
        CameraMenu = tk.Menu(menubar,tearoff=0, background='#000099',
foreground='white',
                activebackground='#004c99', activeforeground='white')
        CameraMenu.add_command(label="Live Feed",command = lambda: self.refresh())
        menubar.add_cascade(label="ViewCammera", menu=CameraMenu)

        self.master.config(menu=menubar)


    def refresh(self):
        os.startfile("Live.py")


        
    def update(self,menubar,VideoMenu):
        FileList = []
        for item in os.listdir("Videos"):
            if item.endswith(".h264"):
                FileList.append(item)
        i=0
        while i<len(FileList):
            VideoMenu.add_command(label=FileList[i],command = lambda: self.playback(FileList,item))
            i+=1

    def playback(seld,FileList,item):
        print(item)
        os.system("start "+r"Videos\""+item)

if __name__ == '__main__':
    # Initialize tkinter
    root = tk.Tk()
    # Select class
    login = LoginPage(root)
    root.mainloop()

