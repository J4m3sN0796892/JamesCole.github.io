import webbrowser

webbrowser.open('http://192.168.0.16:9000')
