import socket
import os
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(("192.168.0.13",8080))
server.listen(10)
print("listening")

(s,(ip,port))=server.accept()


print("connection accepted")

while 1:
    filename = s.recv(4096).decode('latin-1')
    
    # remove absolute path if there is one
    filename = os.path.basename(filename)
     
    
    i=0
    save_path = r"b512d97e7cbf97c273e4db073bbb547aa65a84589227f8f3d9e4a72b9372a24d5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8/"
    name_of_file = filename
    completeName = os.path.join(save_path, name_of_file)         
    while 1:
        with open(completeName, "ab") as f:                     
            bytes_read =s.recv(4096)
            if not bytes_read :
                break
            else :
                f.write(bytes_read)
                f.close()
        print(filename)
        f.close()


    





