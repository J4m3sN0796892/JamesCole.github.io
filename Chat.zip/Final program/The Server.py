import threading
import socket #importing the libraries for the server
import hashlib
import os
class Server(threading.Thread):#class which sets the server up
    __socket = None
    __port = None

    def __init__(self): #sets the server ip and port
        threading.Thread.__init__(self)
        self.__port = 4000
        self.__socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        print("Server Running on host:",self.getipAdress())

    def getipAdress(self):#sets the servers ip address
        return '127.0.0.1'

    def run(self):#this binds the servers ip to a port
        try:
            print("Binding to port:",self.__port)
            self.__socket.bind(('',self.__port))
            while True:
                self.__socket.listen(10)
                global clientSocket
                global clientAddress
                clientSocket,clientAddress=self.__socket.accept()
                client= ClientThread(clientSocket)
                client.start()
        except Exception as error:
            print(error)

        finally:
            try:
                self.__socket.close()
            except:
                pass


class ClientThread(threading.Thread):# this class sets up the multithreading for multiple clients
    __clientSocket= None

    def __init__(self,client): #function to set up the threads
        threading.Thread.__init__(self)
        self.__clientSocket = client
        print("User Logged on")

    def run(self):
        
        Client_Connection()#this function runs the login and from that the chat function

def Client_Connection():
    
   

    Login = clientSocket.recv(1024).decode()
    FileName = "Login.txt"
        
    #checks the login to make sure its valid
        

    if Login == "c1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6fc1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6f":          
        AddUser()
       
    else:
        file = open(FileName,"r")
        for line in file:
                
            if line  == Login + "\n":
                
                message = "Welcome"
                clientSocket.send(message.encode())
                Chat()

               
            else:
                
                clientSocket.send("incorrect login".encode())
                file.close
                Client_Connection()
               
                       
            


    
def AddUser(): # function for the admin which adds new users
    FileName = "Login.txt"
    file = open(FileName , "a")
    
    RecievedCreds = clientSocket.recv(1024).decode()
   
    file.write(RecievedCreds +"\n")
    file.close
    clientSocket.send("New Login Created\nRestarting server Please reconnect".encode())

    # Getting the current work directory (cwd)
   
    # r=root, d=directories, f = files
    for r, d, f in os.walk("E:\Term 2\Final program"):
        for file in f:
            if ".txt" in file:
                
                print("\n\n\n The location of the users file is:\n ->",os.path.join(r, file))



    
    clientSocket.send("New Login Created\nRestarting server Please reconnect".encode())
    
    clientSocket.close()


   
    


            
def Chat():#The Main chat function
         
    message = "Welcome"
    clientSocket.send(message.encode())
    while 1:
        
        MessageContents = ""  
        MessageData = clientSocket.recv(1024).decode()#max number of bytes recv
        SplitMessage = MessageData.split(",")
        Sender,MessageContents = SplitMessage[0],SplitMessage[1]
        print(Sender,":",MessageContents)
        
   
        

    #Disconnect
def Disconnect():

    clientSocket.close()
    input("\n\n press enter to close")
    


server=Server()
server.start()
