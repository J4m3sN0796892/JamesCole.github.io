import socket
import hashlib#The two libraries the client needs
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

def connect():#connects to the server
    
    message=""
    
    print("Waiting for connection")
    s.connect(('127.0.0.1', 4000))
    Login()
    
def Login():#runs the login action. sends credentials to the server
    print("Welcome to the chat program please Enter you username and password to enter the chatroom\n")
    Username = input("Username -> ")
    Password = input("Password -> ")    

    SendPass = hashlib.sha256(Password.encode()).hexdigest()
    SendUser = hashlib.sha256(Username.encode()).hexdigest()

    Credentials = SendUser + SendPass
    s.send(Credentials.encode())
    
    if Credentials == "c1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6fc1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6f":
        Admin()
    else:
            
        data = s.recv(1024).decode()
        if data =="Welcome":
           Chat()
        else:   
            Login()




def Admin():#this is where the admin enters new users information
    NewUsername = input("Please enter the new Username: ")
    NewPassword = input("Please enter the new Password: ")

    SendNewPass = hashlib.sha256(NewPassword.encode()).hexdigest()
    SendNewUser = hashlib.sha256(NewUsername.encode()).hexdigest()

    NewCreds = SendNewUser + SendNewPass
   

    s.send(NewCreds.encode())

    Return = s.recv(1024).decode()
    print(Return)

    


        
def Chat():# This is the main chat room function for the client
    print("Entering chat.......\n\n")
    NickName = input("Please enter a Nickname ->")
    message=""
    print("Welcome"+NickName)
    while message!=NickName + ",end":
        message=""
        message = NickName +","+ str(input("Send ->"))
        
        s.send(message.encode())

    s.close()
    input("\n\n press enter to close")
    print("successfully disconnected from the server")
connect()

